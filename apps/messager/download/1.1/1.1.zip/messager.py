import time
import base64
import os
import sys
import cryptography
import dropbox
from cryptography.fernet import Fernet
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from perorsetti.accedi import main, libreria
accedi=main
lib=libreria
key=open('key.txt').read()
class open_dropbox:
        def __init__(self, file, mode='r', key=key):
                self.mode=mode
                self.file=file
                self.key=key
                self.dbx=dropbox.Dropbox(key)
        def read(self):
                bho, response = self.dbx.files_download(self.file)
                content = response.content
                if self.mode=='r':
                        content=content.decode('utf-8')
                return content
        def write(self, w):
                if type(w)==str:
                        w=w.encode('utf-8')
                self.dbx.files_upload(w, self.file, mode=dropbox.files.WriteMode('overwrite'))
def listdir_dropbox(path, key=key):
        dbx = dropbox.Dropbox(key)
        files_list = []
        result = dbx.files_list_folder(path)
        
        for entry in result.entries:
            files_list.append(entry.name)
        
        return files_list
def make_password(password, salt):
	kdf = PBKDF2HMAC(
		algorithm=hashes.SHA256(),
		length=32,
		salt=salt,
		iterations=100000,
		backend=default_backend()
	)
	return base64.urlsafe_b64encode(kdf.derive(password))
print('nome: ',open('account.txt').read())
if open('account.txt').read()=='':
        name=accedi('messager')
        _n=open('account.txt', 'w')
        _n.write(name)
        _n.close()
        print(name)
else:
        name=open('account.txt').read()
chat=input('chat: ')
def cmd(value=None):
        global name
        exit_v=1
        while exit_v:
                def account():
                        print(name)
                def version():
                        print('')
                def disconnect():
                        global name
                        print('account: ', end='')
                        account()
                        op=input('proced(Y/N): ')
                        if op in ['Y', 'y']:
                                _n=open('account.txt', 'w')
                                _n.write('')
                                _n.close()
                                name=None
                                if open('account.txt').read()=='':
                                        print('Disconnessione effettuata con successo')
                                else:
                                        print('Impossibile disconnettersi')
                        else:
                                print('Disconnessione annullata')
                def delete_message():
                        message=input('message: ')
                        os.remove(message)
                        print('removed')
                def esc():
                        global exit_v
                        exit_v=0
                def restart():
                        import subprocess
                        subprocess.Popen(['py', sys.argv[0]])
                        sys.exit()
                def code(*code):
                        code2=''
                        for x in code:
                                code2+=x+' '
                        exec(code2)
                def change_key():
                        key=input('new key: ')
                        w=open('key.txt', 'w')
                        w.write(kew)
                        w.close()
                if value!=None:
                        #print(value)
                        option=value.split()
                else:
                        option=input('option: ').split()
                if option ==['continue']:
                        chat=input('chat: ')
                        break
                if len(option)>0:
                        command=option[0]+'('
                        for x in option[1:]:
                                command+=x+','
                        if len(option)>1:
                                command=command[:-1]
                        command+=')'
                        try:
                                exec(command)
                        except Exception as error:
                                print(command)
                                print(type(error), error)
                if value!=None:
                        break
if chat in ['settings', 'cmd', 'command']:
        cmd()
if chat in listdir_dropbox(''):
        pass
else:
        input(f'Chat "{chat}" non trovata')
        sys.exit()
if name not in open_dropbox(f'/{chat}/chatuser.dll').read().split('\n'):
        input('Non puoi entrare in questa chat')
        raise Exception('UserError')
key = make_password(input("pass: ").encode("utf-16"), b'\x00')
cipher_suite = Fernet(key)
while True:
        n=0
        for x in listdir_dropbox(f'/{chat}'):
                n+=1
                try:
                        if x=='chatuser.dll':
                                raise NameError
                        print(cipher_suite.decrypt(open_dropbox(f'/{chat}/'+x, 'rb').read()).decode("utf-16"))
                except cryptography.fernet.InvalidToken:
                        if n==0:
                                input('Password sbagliata')
                                sys.exit()
                        else:
                                print('Impossibile leggere il messaggio ('+x+')')
                except cryptography.exceptions.InvalidSignature:
                        input('Password sbagliata()')
                        sys.exit()
                except NameError as ne:
                        if str(ne):
                                raise ne
        inp=input('scrivi: ')
        if inp=='':
                pass
        elif inp.split()[0]=='#cmd':
                #print(inp, inp.split())
                try:
                        cmd(inp.split()[1])
                except IndexError:
                        cmd()
                print('')
        elif inp[0]=='#':
                exec(inp[1:])
        else:
                d=time.asctime().split()
                #2/1/-1
                mesi=['Jen', 'Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
                nm=lib.searchLT(d[1], mesi)
                day=d[2]+'/'+str(nm)+'/'+d[-1]
                t=d[3]
                message=day+' '+t+' '+name+': '+inp
                filen=str(time.time())+'.crypt'
                filew=open_dropbox(f'/{chat}/'+filen, 'wb')
                filew.write(cipher_suite.encrypt(message.encode("utf-16")))
                print('')#open(filen, 'rb').read())
